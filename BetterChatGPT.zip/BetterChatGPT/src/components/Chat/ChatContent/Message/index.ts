export { default } from './Message';
