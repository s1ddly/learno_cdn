export { default } from './LanguageSelector';
