export { default } from './PopupModal';
