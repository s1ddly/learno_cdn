export { default } from './ConfigMenu';
