export { default } from './ShareGPT';
