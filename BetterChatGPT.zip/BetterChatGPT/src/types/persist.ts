import { LocalStorageInterfaceV7oV8 } from './chat';

interface PersistStorageState extends LocalStorageInterfaceV7oV8 {}

export default PersistStorageState;
