export const folderColorOptions = [
  '#be123c', // rose-700
  '#6d28d9', // violet-700
  '#0369a1', // sky-700
  '#047857', // emerald-700
  '#b45309', // amber-700
];
