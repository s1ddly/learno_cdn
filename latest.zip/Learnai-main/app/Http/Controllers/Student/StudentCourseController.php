<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Module;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use League\CommonMark\CommonMarkConverter;

class StudentCourseController extends Controller
{

    public function view($id)
    {
        $course = Course::find($id);

        return view('student.course-details');
    }




    public function moduleVide($id)
    {
        $module = Module::find($id);
        $markdownContent = File::get(public_path('uploads/courses/module/'.$module->file_name));

        // dd($markdownContent);
        // return $markdownContent;

        return view('student.study-page',compact('markdownContent'));
    }


    private function extractContent($html)
    {
        // Initialize DOMDocument
        $dom = new \DOMDocument();
        $dom->loadHTML($html);

        // Extract content from paragraphs
        $paragraphs = [];
        foreach ($dom->getElementsByTagName('p') as $paragraph) {
            $paragraphs[] = $paragraph->nodeValue;
        }

        // Extract content from headings
        $headings = [];
        foreach ($dom->getElementsByTagName('h1') as $heading) {
            $headings[] = $heading->nodeValue;
        }

        // Combine extracted content into an array
        $markdownArray = [
            'paragraphs' => $paragraphs,
            'headings' => $headings,
            // Add more elements as needed
        ];

        return $markdownArray;
    }
}
