<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index()
    {
        $courses = Course::get();
        return view('frontend.index', compact('courses'));
    }

    public function details()
    {
        return view('frontend.course-details');
    }
}
