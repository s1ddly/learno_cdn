<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class DashboardController extends Controller
{
    public function index(Request $request){

        $total_admin   = User::where('is_admin', 1)->count();
        $total_student = User::where('is_admin', 0)->count();
        $toal_course   = Course::count();
        $total_sell    = 0;


        $course_by_month = [];
        $start_date = Carbon::now()->startOfMonth();
        $end_date   = Carbon::now()->subMonths(11)->startOfMonth();

        for($i = $end_date; $i <= $start_date; $i->addMonth()){

            Log::info($i);
            $course_by_month[$i->format('d-m-y')] = Course::whereYear('created_at', $i->year)->whereMonth('created_at', $i->month)->count();
        }

        return view('admin.index', compact('total_admin', 'total_student', 'toal_course', 'total_sell'));
    }
}
