<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index(){
        $users = Student::latest('id')->paginate(10);

        return view('admin.users.index',compact('users'));
    }



    public function create(){

        return view('student.users.create');
    }


    public function store(Request $request){
        $request->validate([
            'name'                  => 'required',
            'email'                 => 'required|unique:users',
            'phone'                 => 'required',
            'password_confirmation' => 'required',
            'password'              => 'required|confirmed',
            'avater'                => 'nullable|file|image|mimes:jpeg,png,jpg,gif,svg',
        ]);


        $user = Student::create([
            'name'                  => $request->name,
            'email'                 => $request->email,
            'phone'                 => $request->phone,
            'password'              => bcrypt($request->password),
        ]);

        if ($request->hasFile('avater')){
            
            $image = $request->file('avater');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $image->move(public_path('uploads/student/avater'), $image_name);

            $user->avater = 'uploads/student/avater/'.$image_name;
            $user->save();
        }


        return redirect()->route('admin.student.index')->with('success','Student Created Successfully');


    }


    

    public function destroy($id){
        
        $user = Student::findOrFail($id);

        if ($user->email == auth()->user()->email){
            return response()->json([
                'error'=>'You can not delete yourself'
            ],422);
        }{

            


            $user->delete();
            return response()->json([
                'success'=>'Student Deleted Successfully'
            ],202);
        }
    }
}
