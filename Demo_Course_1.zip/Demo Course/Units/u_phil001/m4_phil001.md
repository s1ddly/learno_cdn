---
title: "Modern Philosophy: Rationalists & Empiricists"
duration: 5
description: The Modern era ushered in a wave of revolutionary thought, with philosophers keenly re-evaluating the sources and limits of human knowledge. This module juxtaposes the Rationalists, who sought truth in the realm of thought—from Descartes' cogitations to Spinoza's pantheism—against the Empiricists like Locke and Hume, who anchored knowledge in sensory experience.
objectives:
  - Distinguish between rationalist and empiricist approaches to knowledge.
  - Engage with the key texts and arguments of major modern philosophers.
created: 17-10-2023 18:11
updated: 22-10-2023 22:53
---
# Week 4: The Enlightenment: Philosophy of Progress and Autonomy

## **Overview**

The Enlightenment, often called the Age of Reason, was a period where intellectual and cultural forces converged to champion reason, science, and individual rights. Philosophers like Kant, Voltaire, and Rousseau brought forward ideas that challenged traditional authority and paved the way for revolutions and reforms. Dive into this transformative era and understand the profound philosophical shifts that occurred.

**Duration:** 5 hours

---

## **Topics Covered**

- Historical Context: The Age of Reason and its Significance
- Kant: Categorical Imperative, Autonomy, and Sapere Aude
- Voltaire: Critique of Organized Religion and the Defense of Civil Liberties
- Rousseau: Social Contract, General Will, and the Noble Savage
- Diderot and the Encyclopédie: A Testament to Human Knowledge and Progress
- The Legacy of the Enlightenment: Impact on Politics, Ethics, and Culture

---

## **Learning Outcomes**

By the end of this week, students should be able to:

- Recognize the historical and philosophical significance of the Enlightenment.
- Grasp the key philosophical contributions of leading Enlightenment thinkers.
- Engage critically with the ideas of autonomy, freedom, and progress as proposed during this era.
- Reflect on the implications of Enlightenment thought on contemporary society.

---

## **Readings & Resources**

- **Primary Texts:** 
  - *Critique of Pure Reason* and *Grounding for the Metaphysics of Morals* by Immanuel Kant
  - *Candide* by Voltaire
  - *The Social Contract* by Jean-Jacques Rousseau
- **Secondary Text:** *The Enlightenment: And Why It Still Matters* by Anthony Pagden
- **Video:** [The Philosophical Foundations of the Enlightenment](#) *(Note: Insert an appropriate link to a video resource)*

---

## **Assignments**

1. **Essay Assignment:** Reflect on Kant's call to "Dare to know!" (Sapere Aude) and its relevance in the 21st century.
2. **Discussion Board:** Share insights on the paradoxical nature of Rousseau's views on civilization and human nature.

---

## **Assessment**

- **Quiz:** Examine your grasp on the Enlightenment's philosophical tenets and its trailblazing thinkers.

---
