---
title: 20th Century to Present & Conclusion
duration: 5
description: The 20th century and beyond witnessed philosophical diversification, with Analytic and Continental traditions often at odds. From the logical positivists' quest for meaning to the existential and postmodern critiques of foundational truths, this module concludes with a reflection on philosophy's enduring relevance in a rapidly changing global landscape.
objectives:
  - Understand the major debates and movements of 20th-century philosophy.
  - Reflect on the current state and future trajectories of philosophical inquiry.
created: 17-10-2023 18:11
updated: 22-10-2023 22:53
---

# Week 6: 20th Century to Present & Conclusion

## **Overview**

The 20th century saw a proliferation of philosophical movements that responded to unprecedented global events: two World Wars, the rise of technology, and decolonization, among others. From the Analytic-Continental divide to postmodernism, and from feminist philosophy to discussions on artificial intelligence and ethics, this week provides a sweeping view of contemporary thought and its implications.

**Duration:** 5 hours

---

## **Topics Covered**

- The Analytic-Continental Divide: Key Differences and Thinkers
- Phenomenology and Existentialism: Heidegger, Merleau-Ponty, and Arendt
- Postmodernism: Lyotard, Derrida, and Foucault
- Feminist Philosophy: de Beauvoir, Butler, and hooks
- Philosophy of Mind and Artificial Intelligence: Mind-Body Dualism, Consciousness, and Machine Ethics

---

## **Learning Outcomes**

By the end of this week, students should be able to:

- Understand the pivotal philosophical movements and debates of the 20th century.
- Engage with the contributions of key figures within Analytic and Continental traditions.
- Grasp the nuances and challenges posed by postmodernism.
- Reflect on the intersection of philosophy with technology, gender, and race.
- Synthesize the learnings from the entire course and consider future directions for philosophical inquiry.

---

## **Readings & Resources**

- **Primary Texts:** 
  - *Being and Time* by Martin Heidegger
  - *The Postmodern Condition* by Jean-François Lyotard
  - *Gender Trouble* by Judith Butler
  - *The Philosophy of Mind* by Jaegwon Kim
- **Secondary Text:** *The Oxford Handbook of Contemporary Philosophy* by Frank Jackson and Michael Smith
- **Video:** [The Twists and Turns of 20th Century Philosophy](#) *(Note: Insert an appropriate link to a video resource)*

---

## **Assignments**

1. **Essay Assignment:** Analyze the impact of postmodernist thought on contemporary societal structures and beliefs.
2. **Discussion Board:** Debate the ethical considerations surrounding the rapid advancements in artificial intelligence.

---

## **Assessment**

- **Quiz:** Gauge your understanding of the manifold dimensions of 20th-century and contemporary philosophy.
- **Course Feedback:** Provide insights and feedback on the six-week journey, helping us improve for future iterations.

---
