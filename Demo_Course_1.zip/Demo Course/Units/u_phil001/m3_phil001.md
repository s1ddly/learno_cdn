---
title: Hellenistic & Medieval Philosophy
duration: 5
description: Navigating the intricate tapestry of Hellenistic philosophies, we'll explore the Stoics' enduring patience, the Epicureans' pursuit of pleasure, and the Skeptics' challenge to knowledge. Transitioning to the Medieval era, the module highlights the synthesis of faith and reason, with thinkers like Augustine and Aquinas grappling with profound religious and philosophical questions.
objectives:
  - Understand the major schools of Hellenistic philosophy.
  - Examine the intertwining of philosophy and theology during the medieval era.
created: 17-10-2023 18:11
updated: 22-10-2023 22:53
---

# Week 3: Hellenistic & Medieval Philosophy

## **Overview**

Navigating the intricate tapestry of Hellenistic philosophies, we explore the Stoics' enduring patience, the Epicureans' pursuit of pleasure, and the Skeptics' challenge to knowledge. Transitioning to the Medieval era, the module highlights the synthesis of faith and reason, with thinkers like Augustine and Aquinas grappling with profound religious and philosophical questions.

**Duration:** 5 hours

---

## **Topics Covered**

- The Rise of Hellenistic Philosophies: Context and Importance
- Stoicism: The Philosophy of Acceptance and Virtue
- Epicureanism: The Pursuit of Ataraxia and Hedonic Calculus
- Skepticism: The Suspension of Judgment and the Quest for Tranquility
- Augustine: Confessions, The City of God, and the Nature of Evil
- Aquinas: Reconciling Faith and Reason, Five Proofs for the Existence of God

---

## **Learning Outcomes**

By the end of this week, students should be able to:

- Recognize the socio-political changes that gave rise to Hellenistic philosophies.
- Understand the core tenets and practical implications of Stoicism, Epicureanism, and Skepticism.
- Engage with the monumental contributions of Augustine and Aquinas, and their influence on Christian thought.
- Analyze the interplay between philosophy and religion during the Medieval period.

---

## **Readings & Resources**

- **Primary Texts:** 
  - *Letters from a Stoic* by Seneca
  - *Principal Doctrines* by Epicurus
  - *Confessions* by Augustine
  - *Summa Theologica* by Aquinas
- **Secondary Text:** *Philosophy in the Hellenistic and Roman Worlds* by Peter Adamson
- **Video:** [From Athens to Rome: Philosophical Shifts in the Hellenistic Era](#) *(Note: Insert an appropriate link to a video resource)*

---

## **Assignments**

1. **Essay Assignment:** Analyze the Stoic concept of 'virtue' and its relevance in contemporary life.
2. **Discussion Board:** Join the forum debate on the challenges posed by Skepticism to knowledge and belief.

---

## **Assessment**

- **Quiz:** Conclude the week with a quiz that delves into the intricacies of Hellenistic and Medieval philosophical thought.

---
