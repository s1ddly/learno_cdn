---
title: 19th Century Philosophy & Existentialism
duration: 5
description: The 19th century was a hotbed of philosophical evolution. German Idealists, led by figures like Kant and Hegel, sought to reconcile reason and experience. Meanwhile, the existentialist movement, with luminaries such as Kierkegaard and Nietzsche at its helm, delved into the intricacies of individual existence, freedom, and the abyss of the human condition.
objectives:
  - Understand the shift in philosophical paradigms during the 19th century.
  - Engage with existentialist themes and their relevance to modern life.
created: 17-10-2023 18:11
updated: 22-10-2023 22:54
---

# Week 5: 19th Century Philosophy & Existentialism

## **Overview**

The 19th century was a period of intellectual ferment, with profound challenges to traditional values, beliefs, and institutions. This week delves into the precursors and leading figures of Existentialism, from the alienation of Kierkegaard and the will to power of Nietzsche, to the freedom and despair explored by Sartre and de Beauvoir.

**Duration:** 5 hours

---

## **Topics Covered**

- Contextualizing the 19th Century: Industrialization, Secularization, and Discontent
- Kierkegaard: Leap of Faith, Subjectivity, and the Absurd
- Nietzsche: Übermensch, Will to Power, and the Death of God
- Dostoevsky: Freedom, Morality, and Existential Anguish in Fiction
- The Advent of Existentialism: Sartre's Notion of Freedom and de Beauvoir's Ethics of Ambiguity

---

## **Learning Outcomes**

By the end of this week, students should be able to:

- Situate 19th-century philosophy within its broader cultural and historical context.
- Engage with the core themes and concerns of Kierkegaard, Nietzsche, and Dostoevsky.
- Understand the foundations of Existentialist thought, with a focus on notions of freedom, responsibility, and existential angst.
- Reflect on the relevance of Existentialism in contemporary debates on meaning, authenticity, and morality.

---

## **Readings & Resources**

- **Primary Texts:** 
  - *Either/Or* by Søren Kierkegaard
  - *Thus Spoke Zarathustra* by Friedrich Nietzsche
  - *Notes from Underground* by Fyodor Dostoevsky
  - *Being and Nothingness* by Jean-Paul Sartre
  - *The Ethics of Ambiguity* by Simone de Beauvoir
- **Secondary Text:** *Existentialism from Dostoevsky to Sartre* by Walter Kaufmann
- **Video:** [The Dawn of Existentialism: From Despair to Freedom](#) *(Note: Insert an appropriate link to a video resource)*

---

## **Assignments**

1. **Essay Assignment:** Discuss Nietzsche's concept of the Übermensch and its implications for morality and culture.
2. **Discussion Board:** Explore the existential themes in contemporary films, literature, or music and share your insights.

---

## **Assessment**

- **Quiz:** Evaluate your comprehension of the profound shifts in 19th-century philosophy and the emergence of Existentialism.

---
