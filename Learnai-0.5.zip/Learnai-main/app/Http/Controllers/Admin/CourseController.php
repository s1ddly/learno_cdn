<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Module;
use App\Models\Units;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SebastianBergmann\CodeCoverage\Report\Xml\Unit;
use Symfony\Component\Yaml\Yaml;
use ZipArchive;

class CourseController extends Controller
{
    public function index(){
        
        $courses = Course::latest('id')->withCount('units')->paginate(20);

        return view('admin.courses.index', compact('courses'));
    }

    public function create(){
        
        return view('admin.courses.create');
    }

    public function store(Request $request){

        $request->validate([
            'file' => 'required|mimes:zip|max:10240',
        ]);


        $zipFile = $request->file('file');

        $extractedPath = public_path('uploads/' . uniqid());

        $zip = new ZipArchive;


        if ($zip->open($zipFile) === TRUE) {
            $zip->extractTo($extractedPath);
            $zip->close();
        } else {
            return redirect('/')->with('error', 'Failed to extract the zip file.');
        }


        DB::beginTransaction();
        try {

            $getCourses = File::allFiles($extractedPath.'/Demo Course/Courses');
            //seving course 
            foreach ($getCourses as $course_file) {

                if (Course::where('file_name', $course_file->getFilename())->exists()) {
                    return redirect()->back()->with('error', 'Course already exists.');
                }

    
                $fileContent = file_get_contents($course_file->getPathname());
    
                //Geting ready for parsing yaml
                $yamlDocuments = explode("---", $fileContent);
    
                foreach ($yamlDocuments as $yamlDocument) {
    
                    $yamlDocument = trim($yamlDocument);
    
                    if (empty($yamlDocument)) {
                        continue;
                    }
    
                    //parsing Yaml
                    $course_data= Yaml::parse($yamlDocument,Yaml::PARSE_DATETIME);
    
    
                    $course = new Course();
                    $course->title       = $course_data['title'];
                    $course->duration    = $course_data['duration'];
                    $course->description = $course_data['description'];
                    $course->file_name   = $course_file->getFilename();
                    $course->uploaded_by = Auth::user()->id;
                    $course->save();
    
                    
                    foreach ($course_data['units'] as $unit_file) {
    
                        $getUnits = File::allFiles($extractedPath.'/Demo Course/Units/');
                        
                        $foundUnitFile = null;
    
                        // Find the file with the desired name
                        foreach ($getUnits as $unit) {
                            $foundUnitFile = $unit;
                            $unitFileContent = file_get_contents($foundUnitFile->getPathname());
                            if ($unit->getFilename() === $unit_file['ID'] . '.md') {
    
                                //Geting ready for parsing yaml
                                $UnitYamlDocuments = explode("---", $unitFileContent);
    
                                foreach ($UnitYamlDocuments as $key => $UnitYamlDocument) {
    
                                    $UnitYamlDocument = trim($UnitYamlDocument);
                                    if (empty($UnitYamlDocument)) {
                                        continue;
                                    }
    
                                    $unit_data= Yaml::parse($UnitYamlDocument,Yaml::PARSE_DATETIME);
    
                                    $unit = new Units();
                                    $unit->course_id   = $course->id;
                                    $unit->title       = $unit_data['title'];
                                    $unit->duration    = $unit_data['duration'];
                                    $unit->description = $unit_data['description'];
                                    $unit->file_name   = $foundUnitFile->getFilename();
                                    $unit->save();
    
    
                                    foreach ($unit_data['modules'] as $modiuls) {
                                        // $getModuls = File::allFiles($extractedPath.'/Demo Course/Units/');
                        
                                        // $foundModuleFile = null;
    
                                        // foreach ($getModuls as $module) {
                                        //     if ($module->getFilename() === $modiuls['ID'] ) {
                                        //         $foundModuleFile = $module;
                                        //         $moduleFileContent = file_get_contents($foundModuleFile->getPathname());
                                        //         $moduleYamlDocuments = explode("---", $moduleFileContent);
                                        //         foreach ($moduleYamlDocuments as $key => $moduleYamlDocument) {
                                        //             $moduleYamlDocument = trim($moduleYamlDocument);
                                        //             if (empty($moduleYamlDocument)) {
                                        //                 continue;
                                        //             }
    
                                        //             $module_data= Yaml::parse($moduleYamlDocument,Yaml::PARSE_DATETIME);
    
                                        //             $module = new Module();
                                        //             $module->unit_id     = $unit->id;
                                        //             $module->title       = $module_data['title'];
                                        //             $module->duration    = $module_data['duration'];
                                        //             $module->file_name   = $foundModuleFile->getFilename();
                                        //             $module->save();
                                        //         }
    
                                        //         Storage::disk('public_path')->put('uploads/courses/units/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                                
                                        //     }
                                        // }
    
                                        $module = new Module();
                                        $module->unit_id     = $unit->id;
                                        $module->title       = $modiuls['title'];
                                        $module->file_name   = $modiuls['ID'];
                                        $module->save();
    
                                        
                                    }
                                    
                                }
    
                                Storage::disk('public_path')->put('uploads/courses/units/'.$unit_data['title'].'/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                            }else{
                                $extention = explode('.',$foundUnitFile->getFilename())[1];
    
    
                                if ($extention == 'md')  {
                                    Storage::disk('public_path')->put('uploads/courses/module/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                }else {
                                    if ($extention == 'png' || $extention == 'jpg' || $extention == 'gif' || $extention == 'jpeg') {

                                        $image_name =  $foundUnitFile->getFilename() . '-' .hexdec(uniqid());
                                        Storage::disk('public_path')->put('uploads/courses/course_image/' . $image_name, file_get_contents($foundUnitFile->getPathname()));
                                        $course->image = $image_name;
                                        $course->save();
                                    } else {

                                        $video_name =  $foundUnitFile->getFilename() . '-' .hexdec(uniqid());
                                        Storage::disk('public_path')->put('uploads/courses/course_video/' . $video_name, file_get_contents($foundUnitFile->getPathname()));
                                        $course->video = $video_name;
                                        $course->save();
                                    }
                                }
                            }
                        }
                    }
                }
            
    
                Storage::disk('public_path')->put('uploads/courses/course/' . $course_file->getFilename(), file_get_contents($course_file->getPathname()));
            }

            DB::commit();

            File::deleteDirectory($extractedPath);
            
        } catch (\Throwable $th) {
            DB::rollBack();
            File::deleteDirectory($extractedPath);
            
            Log::info($th->getMessage());
            // dd($th);
            return redirect()->back()->with('error', "Something went wrong");
        }
      


        return redirect()->back()->with('success', 'Course created successfully.');
    }

    public function update(Request $request,$id){
        // dd($request->file('file'));
        
        $request->validate([
            'file' => 'required|mimes:zip|max:10240',
        ]);

        if (Course::find($id) == null) {
            
            return redirect()->back()->with('error','Course not found');
        }


        $zipFile = $request->file('file');

        $extractedPath = public_path('uploads/' . uniqid());

        $zip = new ZipArchive;


        if ($zip->open($zipFile) === TRUE) {
            $zip->extractTo($extractedPath);
            $zip->close();
        } else {
            return redirect('/')->with('error', 'Failed to extract the zip file.');
        }


        DB::beginTransaction();


        

        try {

            $getCourses = File::allFiles($extractedPath.'/Demo Course/Courses');
 
            foreach ($getCourses as $course_file) {
    
                $fileContent = file_get_contents($course_file->getPathname());
    
                //Geting ready for parsing yaml
                $yamlDocuments = explode("---", $fileContent);
    
                foreach ($yamlDocuments as $yamlDocument) {
    
                    $yamlDocument = trim($yamlDocument);
    
                    if (empty($yamlDocument)) {
                        continue;
                    }
    
                    //parsing Yaml
                    $course_data= Yaml::parse($yamlDocument,Yaml::PARSE_DATETIME);

    
                    $course = Course::find($id);
                    $course->title       = $course_data['title'];
                    $course->duration    = $course_data['duration'];
                    $course->description = $course_data['description'];
                    $course->file_name   = $course_file->getFilename();
                    $course->save();
    
                    
                    foreach ($course_data['units'] as $unit_file) {
    
                        $getUnits = File::allFiles($extractedPath.'/Demo Course/Units/');
                        
                        $foundUnitFile = null;
    
                        // Find the file with the desired name
                        foreach ($getUnits as $unit) {
                            $foundUnitFile = $unit;
                            $unitFileContent = file_get_contents($foundUnitFile->getPathname());
                            if ($unit->getFilename() === $unit_file['ID'] . '.md') {
    
                                //Geting ready for parsing yaml
                                $UnitYamlDocuments = explode("---", $unitFileContent);
    
                                foreach ($UnitYamlDocuments as $key => $UnitYamlDocument) {
    
                                    $UnitYamlDocument = trim($UnitYamlDocument);
                                    if (empty($UnitYamlDocument)) {
                                        continue;
                                    }
    
                                    $unit_data= Yaml::parse($UnitYamlDocument,Yaml::PARSE_DATETIME);

                                    $unit = Units::where('file_name',$foundUnitFile->getFilename())->first();

                                    if ($unit) {
                                        $unit->title       = $unit_data['title'];
                                        $unit->duration    = $unit_data['duration'];
                                        $unit->description = $unit_data['description'];
                                        $unit->file_name   = $foundUnitFile->getFilename();
                                        $unit->save();
                                    }else {
                                        $unit = new Units();
                                        $unit->course_id   = $course->id;
                                        $unit->title       = $unit_data['title'];
                                        $unit->duration    = $unit_data['duration'];
                                        $unit->description = $unit_data['description'];
                                        $unit->file_name   = $foundUnitFile->getFilename();
                                        $unit->save();
                                    }
    
                                    foreach ($unit_data['modules'] as $modiuls) {
                                        // $getModuls = File::allFiles($extractedPath.'/Demo Course/Units/');
                        
                                        // $foundModuleFile = null;
    
                                        // foreach ($getModuls as $module) {
                                        //     if ($module->getFilename() === $modiuls['ID'] ) {
                                        //         $foundModuleFile = $module;
                                        //         $moduleFileContent = file_get_contents($foundModuleFile->getPathname());
                                        //         $moduleYamlDocuments = explode("---", $moduleFileContent);
                                        //         foreach ($moduleYamlDocuments as $key => $moduleYamlDocument) {
                                        //             $moduleYamlDocument = trim($moduleYamlDocument);
                                        //             if (empty($moduleYamlDocument)) {
                                        //                 continue;
                                        //             }
    
                                        //             $module_data= Yaml::parse($moduleYamlDocument,Yaml::PARSE_DATETIME);
    
                                        //             $module = new Module();
                                        //             $module->unit_id     = $unit->id;
                                        //             $module->title       = $module_data['title'];
                                        //             $module->duration    = $module_data['duration'];
                                        //             $module->file_name   = $foundModuleFile->getFilename();
                                        //             $module->save();
                                        //         }
    
                                        //         Storage::disk('public_path')->put('uploads/courses/units/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                                
                                        //     }
                                        // }

                                        $existing_module = Units::where('file_name',$foundUnitFile->getFilename())->first();
                                        if ($existing_module) {
                                            $existing_module->title       = $modiuls['title'];
                                            $existing_module->file_name   = $modiuls['ID'];
                                            $existing_module->save();
                                        }else {
                                            $module = new Module();
                                            $module->unit_id     = $unit->id;
                                            $module->title       = $modiuls['title'];
                                            $module->file_name   = $modiuls['ID'];
                                            $module->save();
                                        }
                                    }
                                }
    
                                Storage::disk('public_path')->put('uploads/courses/units/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                            }else{
                                $extention = explode('.',$foundUnitFile->getFilename())[1];
    
    
                                if ($extention == 'md')  {
                                    Storage::disk('public_path')->put('uploads/courses/module/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                }else {
                                    if ($extention == 'png' || $extention == 'jpg' || $extention == 'gif' || $extention == 'jpeg') {
                                        Storage::disk('public_path')->put('uploads/courses/course_image/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                        $course->image = $foundUnitFile->getFilename();
                                        $course->save();
                                    } else {
                                        Storage::disk('public_path')->put('uploads/courses/course_video/' . $foundUnitFile->getFilename(), file_get_contents($foundUnitFile->getPathname()));
                                        $course->video = $foundUnitFile->getFilename();
                                        $course->save();
                                    }
                                }
                            }
                        }
                    }

                    break;
                }
            
    
                Storage::disk('public_path')->put('uploads/courses/course/' . $course_file->getFilename(), file_get_contents($course_file->getPathname()));
            }

            File::deleteDirectory($extractedPath);
            DB::commit();
            
        } catch (\Throwable $th) {
            File::deleteDirectory($extractedPath);
            DB::rollBack();

            Log::info($th->getMessage());

            return redirect()->back()->with('error', "Something went wrong");
        }
      

        

        return redirect()->back()->with('success', 'Course updated successfully.');
    }

    public function destroy($id){
        // dd($request->file('file'));
        
        $course = Course::find($id);

        if ($course == null) {
            return redirect()->back()->with('error', 'Course not found');
        }
        $course->delete();

        return response()->json([
            'success' => true,
            'message' => 'Course deleted successfully'
        ],202);
    }
}
