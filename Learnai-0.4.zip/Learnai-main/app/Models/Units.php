<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Units extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    function getCourse() {
        
        return $this->belongsTo(Course::class, 'course_id', 'id');
    }

    function getUnit(){
        
        return $this->hasMany(Module::class, 'unit_id', 'id');
    }

}
