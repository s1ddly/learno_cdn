<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Student;
use Illuminate\Http\Request;

class StudentController extends Controller
{
    public function index(){
        $users = Student::latest('id')->paginate(10);

        return view('admin.student.index',compact('users'));
    }



    public function create(){

        return view('admin.student.create');
    }


    public function store(Request $request){
        $request->validate([
            'first_name'            => 'required|max:255',
            'last_name'             => 'required|max:255',
            'email'                 => 'required|unique:students',
            'phone'                 => 'required',
            'password_confirmation' => 'required',
            'password'              => 'required|confirmed',
            'avater'                => 'nullable|file|image|mimes:jpeg,png,jpg,gif,svg',
            'gender'                => 'required|in:0,1,2',
        ]);


        $user = Student::create([
            'first_name'            => $request->first_name,
            'last_name'             => $request->last_name,
            'email'                 => $request->email,
            'phone'                 => $request->phone,
            'password'              => bcrypt($request->password),
            'gender'                => $request->gender
        ]);

        if ($request->hasFile('avater')){
            
            $image = $request->file('avater');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $image->move(public_path('uploads/student/avater'), $image_name);

            $user->avater = 'uploads/student/avater/'.$image_name;
            $user->save();
        }


        return redirect()->route('admin.student.index')->with('success','Student Created Successfully');


    }


    public function edit($id){

        $user = Student::findOrFail($id);
        return view('admin.student.edit',compact('user'));
    }



    public function update(Request $request,$id){
        $request->validate([
            'first_name'            => 'required|max:255',
            'last_name'             => 'required|max:255',
            'email'                 => 'required|unique:students,email,'.$id,
            'phone'                 => 'required',
            'avater'                => 'nullable|file|image|mimes:jpeg,png,jpg,gif,svg',
            'gender'                => 'required|in:0,1,2',
        ]);


        $user = Student::findOrFail($id)->update([
            'first_name'            => $request->first_name,
            'last_name'             => $request->last_name,
            'email'                 => $request->email,
            'phone'                 => $request->phone,
            'gender'                => $request->gender
        ]);

        if ($request->hasFile('avater')){
            
            $image = $request->file('avater');
            $image_name = time().'.'.$image->getClientOriginalExtension();
            $image->move(public_path('uploads/student/avater'), $image_name);

            $user->avater = 'uploads/student/avater/'.$image_name;
            $user->save();
        }


        return redirect()->route('admin.student.index')->with('success','Student Created Successfully');


    }

    

    public function destroy($id){
        
        $user = Student::findOrFail($id);
        $user->delete();
        return response()->json([
            'success'=>'Student Deleted Successfully'
        ],202);
        
    }
}
